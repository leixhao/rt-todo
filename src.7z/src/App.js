import React from "react";
import LayoutBox from './components/Layout/index'

export default function App() {
  return (
    <LayoutBox />
  );
}
import React, { Component } from 'react';
import {Button} from 'antd';
class About extends Component {
  render() {
    return (
      <div>
        <Button>跳转到关于页面</Button>
      </div>
    );
  }
}

export default About;

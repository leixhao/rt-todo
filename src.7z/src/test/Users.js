import React, { Component } from 'react';
import { Button } from 'antd';
class Users extends Component {
  render() {
    return (
      <div>
        <Button>跳转到员工页面</Button>
      </div>
    );
  }
}

export default Users;
